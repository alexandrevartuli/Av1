package com.oficial.racefast;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;
import android.content.Context;
import android.util.AttributeSet;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import java.util.ArrayList;
import java.util.List;
import android.graphics.Color;
import android.graphics.Paint;




public class RaceView extends View {
    private Bitmap trackBitmap; // Bitmap para a pista
    private List<Car> cars; // Lista de carros
    private Handler handler; // Handler para atualizar a tela
    private Runnable runnable; // Runnable para o loop de atualização
    private boolean isRunning = false; // Flag para controlar se a corrida está em andamento
    private int trackWidth, trackHeight; // Largura e altura da pista
    private Bitmap scaledTrackBitmap;


    public RaceView(Context context) {
        super(context);
        init();
    }

    public RaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RaceView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        trackBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.pista);
        cars = new ArrayList<>();
        handler = new Handler();
    }
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        // Escalonar o trackBitmap para as dimensões atuais do RaceView
        scaledTrackBitmap = Bitmap.createScaledBitmap(trackBitmap, w, h, true);
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Desenhar a pista escalonada
        canvas.drawBitmap(scaledTrackBitmap, 0, 0, null);

        // Desenhar cada carro
        for (Car car : cars) {
            car.draw(canvas);
        }
    }



    public void startRace() {
        isRunning = true;
        runnable = new Runnable() {
            @Override
            public void run() {
                if (isRunning) {
                    // Mover carros
                    for (Car car : cars) {
                        car.move();
                    }

                    // Redesenhar a tela
                    invalidate();

                    // Chamar novamente após um intervalo (16ms para ~60 FPS)
                    handler.postDelayed(this, 16);
                }
            }
        };
        handler.post(runnable);
    }
    public void pauseRace() {
        isRunning = false;
        handler.removeCallbacks(runnable);
    }
    public void finishRace() {
        isRunning = false;
        handler.removeCallbacks(runnable);
        // Opcional: Limpar carros ou resetar estados
        cars.clear();
        invalidate(); // Redesenhar para limpar a tela
    }
    public void addCars(int quantity) {
        cars.clear(); // Limpar carros existentes
        for (int i = 0; i < quantity; i++) {
            // Carregar imagem do carro
            Bitmap carBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.car1); // Use imagens diferentes se tiver

            // Definir uma cor única para cada carro
            Paint paint = new Paint();
            int[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.MAGENTA};
            paint.setColor(colors[i % colors.length]);

            // Posicionamento inicial (ajuste conforme necessário)
            int startX = 100 + (i * 50);
            int startY = 100;

            // Velocidade aleatória ou fixa
            double speed = 3 + (i * 0.5);

            // Criar o carro e adicionar à lista
            Car car = new Car(this, carBitmap, scaledTrackBitmap, startX, startY, speed, paint);
            cars.add(car);
        }
        invalidate(); // Redesenhar para mostrar os carros adicionados
    }
    public List<Car> getCars() {
        return cars;
    }









}
