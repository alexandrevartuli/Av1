package com.oficial.racefast;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Car {
    private Bitmap carBitmap;
    private int x;
    private int y;
    private int fuelTank;
    private double speed;
    private int laps;
    private int distance;
    private int penalty;
    private Map<Integer, Integer> sensor;
    private double directionX;
    private double directionY;
    private Paint paint;
    private RaceView raceView; // Referência ao RaceView
    private Bitmap trackBitmap;
    private Map<Integer, Boolean> sensorReadings;




    public Car(RaceView raceView, Bitmap bitmap, Bitmap trackBitmap, int startX, int startY, double speed, Paint paint) {
        this.raceView = raceView;
        this.carBitmap = bitmap;
        this.trackBitmap = trackBitmap; // Usar o bitmap escalonado
        this.x = startX;
        this.y = startY;
        this.speed = speed;
        this.paint = paint;
        this.directionX = 1; // Direção inicial
        this.directionY = 0;
        this.sensor = new HashMap<>();
        this.fuelTank = 100; // Valor inicial do tanque de combustível
        this.laps = 0;
        this.distance = 0;
        this.penalty = 0;
    }

    public void move() {
        // Atualizar sensores
        updateSensors();

        // Decidir a direção com base nas leituras dos sensores
        decideDirection();

        // Atualizar posição
        x += (int) (directionX * speed);
        y += (int) (directionY * speed);
        distance += speed;

        // Verificar colisões com outros carros
        checkCollisions();
    }
    private void updateSensors() {
        // Raio de detecção (distância à frente do carro)
        int detectionDistance = 50; // Ajuste conforme necessário

        // Ângulos dos sensores em relação à direção atual (em graus)
        int[] sensorAngles = {-60, -30, 0, 30, 60};

        sensorReadings = new HashMap<>();

        for (int angleOffset : sensorAngles) {
            double sensorAngle = Math.toRadians(getCurrentAngle() + angleOffset);
            int sensorX = x + (int) (Math.cos(sensorAngle) * detectionDistance);
            int sensorY = y + (int) (Math.sin(sensorAngle) * detectionDistance);

            boolean onTrack = isOnTrack(sensorX, sensorY);
            sensorReadings.put(angleOffset, onTrack);
        }
    }
    private void decideDirection() {
        if (sensorReadings.get(0)) {
            // Sensor central detecta pista - manter direção
            return;
        } else if (sensorReadings.get(-30)) {
            // Ajustar direção para a esquerda
            adjustDirection(-5); // Ajuste o valor para controlar a suavidade
        } else if (sensorReadings.get(30)) {
            // Ajustar direção para a direita
            adjustDirection(5); // Ajuste o valor para controlar a suavidade
        } else {
            // Nenhum sensor detecta pista - inverter direção
            adjustDirection(180);
            penalty++;
        }
    }
    private double getCurrentAngle() {
        return Math.toDegrees(Math.atan2(directionY, directionX));
    }
    private void adjustDirection(int angleOffset) {
        double currentAngle = getCurrentAngle();
        double newAngle = currentAngle + angleOffset;
        directionX = Math.cos(Math.toRadians(newAngle));
        directionY = Math.sin(Math.toRadians(newAngle));
    }



    private boolean isOnTrack(int x, int y) {
        if (x >= 0 && x < trackBitmap.getWidth() && y >= 0 && y < trackBitmap.getHeight()) {
            int pixelColor = trackBitmap.getPixel(x, y);
            // Verificar se o pixel é suficientemente claro (próximo ao branco)
            int tolerance = 50; // Ajuste conforme necessário
            int red = Color.red(pixelColor);
            int green = Color.green(pixelColor);
            int blue = Color.blue(pixelColor);
            return red > 255 - tolerance && green > 255 - tolerance && blue > 255 - tolerance;
        }
        return false;
    }


    private void changeDirection() {
        // Gerar uma nova direção aleatória
        double angle = Math.toRadians(new Random().nextInt(360));
        directionX = Math.cos(angle);
        directionY = Math.sin(angle);
    }




    public void draw(Canvas canvas) {
        canvas.drawBitmap(carBitmap, x, y, paint);
    }

    private void updateSensor() {
        // Simular a leitura dos sensores em diferentes direções

        // Verificar a distância à frente
        int frontDistance = checkDistanceInDirection(x + (int)(directionX * speed), y + (int)(directionY * speed));
        sensor.put(0, frontDistance);

        // Verificar a distância à direita
        int rightDistance = checkDistanceInDirection(x + (int)(directionY * speed), y - (int)(directionX * speed));
        sensor.put(90, rightDistance);

        // Verificar a distância atrás
        int backDistance = checkDistanceInDirection(x - (int)(directionX * speed), y - (int)(directionY * speed));
        sensor.put(180, backDistance);

        // Verificar a distância à esquerda
        int leftDistance = checkDistanceInDirection(x - (int)(directionY * speed), y + (int)(directionX * speed));
        sensor.put(270, leftDistance);
    }

    private int checkDistanceInDirection(int x, int y) {
        // Aqui você pode implementar a lógica para verificar a distância em uma determinada posição (x, y)
        // Por enquanto, retornaremos um valor fixo
        return 100; // Valor fictício representando a distância
    }

    private void checkCollisions() {
        // Colisão com bordas da pista
        if (x < 0 || x + carBitmap.getWidth() > raceView.getWidth()) {
            directionX *= -1;
            penalty++;
        }
        if (y < 0 || y + carBitmap.getHeight() > raceView.getHeight()) {
            directionY *= -1;
            penalty++;
        }

        // Removemos a colisão com outros carros
        // Agora, os carros passarão uns pelos outros sem alterar a direção
    }


    public Rect getRect() {
        return new Rect(x, y, x + carBitmap.getWidth(), y + carBitmap.getHeight());
    }

    // Outros métodos e atributos conforme necessário
}
